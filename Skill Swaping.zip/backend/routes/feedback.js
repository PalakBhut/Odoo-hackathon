import express from "express"
import { body, validationResult } from "express-validator"
import Feedback from "../models/Feedback.js" // Ensure .js extension
import SwapRequest from "../models/SwapRequest.js" // Ensure .js extension
import User from "../models/User.js" // Ensure .js extension
import { authenticateToken } from "../middleware/auth.js" // Ensure .js extension

const router = express.Router()

// Create feedback
router.post(
  "/",
  authenticateToken,
  [
    body("swapRequestId").isMongoId().withMessage("Valid swap request ID required"),
    body("rating").isInt({ min: 1, max: 5 }).withMessage("Rating must be between 1 and 5"),
    body("comment").optional().isLength({ max: 500 }).withMessage("Comment too long"),
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({ error: errors.array()[0].msg })
      }

      const { swapRequestId, rating, comment } = req.body

      // Check if swap request exists and is completed
      const swapRequest = await SwapRequest.findById(swapRequestId)
      if (!swapRequest) {
        return res.status(404).json({ error: "Swap request not found" })
      }

      if (swapRequest.status !== "completed") {
        return res.status(400).json({ error: "Can only review completed swaps" })
      }

      // Check if user is part of the swap
      const isRequester = swapRequest.requester.toString() === req.user._id.toString()
      const isRecipient = swapRequest.recipient.toString() === req.user._id.toString()

      if (!isRequester && !isRecipient) {
        return res.status(403).json({ error: "Unauthorized" })
      }

      // Determine who is being reviewed
      const revieweeId = isRequester ? swapRequest.recipient : swapRequest.requester

      // Check if feedback already exists
      const existingFeedback = await Feedback.findOne({
        swapRequest: swapRequestId,
        reviewer: req.user._id,
      })

      if (existingFeedback) {
        return res.status(400).json({ error: "You have already reviewed this swap" })
      }

      // Create feedback
      const feedback = await Feedback.create({
        swapRequest: swapRequestId,
        reviewer: req.user._id,
        reviewee: revieweeId,
        rating,
        comment,
      })

      // Update user's rating
      const reviewee = await User.findById(revieweeId)
      const newCount = reviewee.rating.count + 1
      const newAverage = (reviewee.rating.average * reviewee.rating.count + rating) / newCount

      await User.findByIdAndUpdate(revieweeId, {
        "rating.average": newAverage,
        "rating.count": newCount,
      })

      await feedback.populate([
        { path: "reviewer", select: "name profilePhoto" },
        { path: "reviewee", select: "name profilePhoto" },
      ])

      res.status(201).json({ feedback })
    } catch (error) {
      console.error("Feedback creation error:", error)
      res.status(500).json({ error: "Failed to create feedback" })
    }
  },
)

// Get feedback for a user
router.get("/user/:userId", authenticateToken, async (req, res) => {
  try {
    const feedback = await Feedback.find({ reviewee: req.params.userId })
      .populate([
        { path: "reviewer", select: "name profilePhoto" },
        { path: "swapRequest", select: "offeredSkill requestedSkill" },
      ])
      .sort({ createdAt: -1 })

    res.json({ feedback })
  } catch (error) {
    console.error("Feedback fetch error:", error)
    res.status(500).json({ error: "Failed to fetch feedback" })
  }
})

export default router
