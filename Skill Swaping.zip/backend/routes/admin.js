import express from "express"
import { body, validationResult } from "express-validator"
import User from "../models/User.js" // Ensure .js extension
import SwapRequest from "../models/SwapRequest.js" // Ensure .js extension
import Feedback from "../models/Feedback.js" // Ensure .js extension
import PlatformMessage from "../models/PlatformMessage.js" // Ensure .js extension
import { requireAdmin } from "../middleware/auth.js" // Ensure .js extension

const router = express.Router()

// Get admin dashboard stats
router.get("/stats", requireAdmin, async (req, res) => {
  try {
    const totalUsers = await User.countDocuments({ isBanned: false })
    const totalSwaps = await SwapRequest.countDocuments()
    const completedSwaps = await SwapRequest.countDocuments({ status: "completed" })
    const pendingSwaps = await SwapRequest.countDocuments({ status: "pending" })
    const totalFeedback = await Feedback.countDocuments()
    const bannedUsers = await User.countDocuments({ isBanned: true })

    const stats = {
      totalUsers,
      totalSwaps,
      completedSwaps,
      pendingSwaps,
      totalFeedback,
      bannedUsers,
      completionRate: totalSwaps > 0 ? ((completedSwaps / totalSwaps) * 100).toFixed(1) : 0,
    }

    res.json({ stats })
  } catch (error) {
    console.error("Admin stats error:", error)
    res.status(500).json({ error: "Failed to fetch stats" })
  }
})

// Get all users
router.get("/users", requireAdmin, async (req, res) => {
  try {
    const { page = 1, limit = 20, search, status } = req.query
    const skip = (page - 1) * limit

    const query = {}

    if (search) {
      query.$or = [{ name: { $regex: search, $options: "i" } }, { email: { $regex: search, $options: "i" } }]
    }

    if (status === "banned") {
      query.isBanned = true
    } else if (status === "active") {
      query.isBanned = false
    }

    const users = await User.find(query)
      .select("-password")
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number.parseInt(limit))

    const total = await User.countDocuments(query)

    res.json({
      users,
      pagination: {
        page: Number.parseInt(page),
        limit: Number.parseInt(limit),
        total,
        pages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error("Admin users fetch error:", error)
    res.status(500).json({ error: "Failed to fetch users" })
  }
})

// Ban/unban user
router.put(
  "/users/:id/ban",
  requireAdmin,
  [
    body("banned").isBoolean().withMessage("Banned status required"),
    body("reason").optional().isLength({ max: 200 }).withMessage("Reason too long"),
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({ error: errors.array()[0].msg })
      }

      const { banned, reason } = req.body

      const updateData = {
        isBanned: banned,
        banReason: banned ? reason : null,
      }

      const user = await User.findByIdAndUpdate(req.params.id, updateData, { new: true }).select("-password")

      if (!user) {
        return res.status(404).json({ error: "User not found" })
      }

      res.json({ user })
    } catch (error) {
      console.error("User ban error:", error)
      res.status(500).json({ error: "Failed to update user status" })
    }
  },
)

// Get all swap requests
router.get("/swap-requests", requireAdmin, async (req, res) => {
  try {
    const { page = 1, limit = 20, status } = req.query
    const skip = (page - 1) * limit

    const query = {}
    if (status) {
      query.status = status
    }

    const swapRequests = await SwapRequest.find(query)
      .populate([
        { path: "requester", select: "name email profilePhoto" },
        { path: "recipient", select: "name email profilePhoto" },
      ])
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number.parseInt(limit))

    const total = await SwapRequest.countDocuments(query)

    res.json({
      swapRequests,
      pagination: {
        page: Number.parseInt(page),
        limit: Number.parseInt(limit),
        total,
        pages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error("Admin swap requests fetch error:", error)
    res.status(500).json({ error: "Failed to fetch swap requests" })
  }
})

// Create platform message
router.post(
  "/messages",
  requireAdmin,
  [
    body("title").notEmpty().withMessage("Title required"),
    body("content").notEmpty().withMessage("Content required"),
    body("type").isIn(["announcement", "maintenance", "feature", "warning"]).withMessage("Invalid type"),
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({ error: errors.array()[0].msg })
      }

      const { title, content, type } = req.body

      const message = await PlatformMessage.create({
        title,
        content,
        type,
        createdBy: req.user._id,
      })

      await message.populate({ path: "createdBy", select: "name" })

      res.status(201).json({ message })
    } catch (error) {
      console.error("Platform message creation error:", error)
      res.status(500).json({ error: "Failed to create message" })
    }
  },
)

// Get platform messages
router.get("/messages", requireAdmin, async (req, res) => {
  try {
    const messages = await PlatformMessage.find()
      .populate({ path: "createdBy", select: "name" })
      .sort({ createdAt: -1 })

    res.json({ messages })
  } catch (error) {
    console.error("Platform messages fetch error:", error)
    res.status(500).json({ error: "Failed to fetch messages" })
  }
})

// Export data as CSV
router.get("/export/:type", requireAdmin, async (req, res) => {
  try {
    const { type } = req.params
    let data = []
    let filename = ""

    switch (type) {
      case "users":
        data = await User.find().select("-password").lean()
        filename = "users.csv"
        break
      case "swaps":
        data = await SwapRequest.find().populate("requester", "name email").populate("recipient", "name email").lean()
        filename = "swap-requests.csv"
        break
      case "feedback":
        data = await Feedback.find().populate("reviewer", "name email").populate("reviewee", "name email").lean()
        filename = "feedback.csv"
        break
      default:
        return res.status(400).json({ error: "Invalid export type" })
    }

    // Convert to CSV format
    if (data.length === 0) {
      return res.status(404).json({ error: "No data to export" })
    }

    const headers = Object.keys(data[0]).join(",")
    const rows = data.map((item) => Object.values(item).join(","))
    const csv = [headers, ...rows].join("\n")

    res.setHeader("Content-Type", "text/csv")
    res.setHeader("Content-Disposition", `attachment; filename=${filename}`)
    res.send(csv)
  } catch (error) {
    console.error("Export error:", error)
    res.status(500).json({ error: "Failed to export data" })
  }
})

export default router
