import { NextResponse } from "next/server"
import connectDB from "@/lib/db"
import SwapRequest from "@/lib/models/SwapRequest"
import { requireAuth } from "@/middleware/auth"

export async function PUT(request, { params }) {
  try {
    await connectDB()
    const user = await requireAuth(request)

    const { action } = await request.json()
    const swapRequest = await SwapRequest.findById(params.id)

    if (!swapRequest) {
      return NextResponse.json({ error: "Swap request not found" }, { status: 404 })
    }

    // Check permissions
    const isRecipient = swapRequest.recipient.toString() === user._id.toString()
    const isRequester = swapRequest.requester.toString() === user._id.toString()

    if (!isRecipient && !isRequester) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    const updateData = {}

    switch (action) {
      case "accept":
        if (!isRecipient) {
          return NextResponse.json({ error: "Only recipient can accept requests" }, { status: 403 })
        }
        updateData.status = "accepted"
        break

      case "reject":
        if (!isRecipient) {
          return NextResponse.json({ error: "Only recipient can reject requests" }, { status: 403 })
        }
        updateData.status = "rejected"
        break

      case "complete":
        if (swapRequest.status !== "accepted") {
          return NextResponse.json({ error: "Can only complete accepted requests" }, { status: 400 })
        }
        updateData.status = "completed"
        updateData.completedAt = new Date()
        break

      case "cancel":
        if (!isRequester) {
          return NextResponse.json({ error: "Only requester can cancel requests" }, { status: 403 })
        }
        if (swapRequest.status !== "pending") {
          return NextResponse.json({ error: "Can only cancel pending requests" }, { status: 400 })
        }
        updateData.status = "cancelled"
        break

      default:
        return NextResponse.json({ error: "Invalid action" }, { status: 400 })
    }

    const updatedRequest = await SwapRequest.findByIdAndUpdate(params.id, updateData, { new: true }).populate([
      { path: "requester", select: "name profilePhoto rating" },
      { path: "recipient", select: "name profilePhoto rating" },
    ])

    return NextResponse.json({ swapRequest: updatedRequest })
  } catch (error) {
    console.error("Swap request update error:", error)
    return NextResponse.json({ error: "Failed to update swap request" }, { status: 500 })
  }
}

export async function DELETE(request, { params }) {
  try {
    await connectDB()
    const user = await requireAuth(request)

    const swapRequest = await SwapRequest.findById(params.id)

    if (!swapRequest) {
      return NextResponse.json({ error: "Swap request not found" }, { status: 404 })
    }

    // Only requester can delete their own requests
    if (swapRequest.requester.toString() !== user._id.toString()) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    await SwapRequest.findByIdAndDelete(params.id)

    return NextResponse.json({ message: "Swap request deleted successfully" })
  } catch (error) {
    console.error("Swap request deletion error:", error)
    return NextResponse.json({ error: "Failed to delete swap request" }, { status: 500 })
  }
}
