import express from "express"
import { body, validationResult } from "express-validator"
import SwapRequest from "../models/SwapRequest.js" // Ensure .js extension
import User from "../models/User.js" // Ensure .js extension
import { authenticateToken } from "../middleware/auth.js" // Ensure .js extension

const router = express.Router()

// Create swap request
router.post(
  "/",
  authenticateToken,
  [
    body("recipientId").isMongoId().withMessage("Valid recipient ID required"),
    body("offeredSkill.name").notEmpty().withMessage("Offered skill name required"),
    body("requestedSkill.name").notEmpty().withMessage("Requested skill name required"),
    body("message").optional().isLength({ max: 500 }).withMessage("Message too long"),
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({ error: errors.array()[0].msg })
      }

      const { recipientId, offeredSkill, requestedSkill, message } = req.body

      // Check if recipient exists and is not banned
      const recipient = await User.findById(recipientId)
      if (!recipient || recipient.isBanned) {
        return res.status(404).json({ error: "Recipient not found or unavailable" })
      }

      // Prevent self-requests
      if (req.user._id.toString() === recipientId) {
        return res.status(400).json({ error: "Cannot send swap request to yourself" })
      }

      // Check for existing pending request
      const existingRequest = await SwapRequest.findOne({
        requester: req.user._id,
        recipient: recipientId,
        status: "pending",
      })

      if (existingRequest) {
        return res.status(400).json({ error: "You already have a pending request with this user" })
      }

      // Create swap request
      const swapRequest = await SwapRequest.create({
        requester: req.user._id,
        recipient: recipientId,
        offeredSkill,
        requestedSkill,
        message,
      })

      // Populate the request with user data
      await swapRequest.populate([
        { path: "requester", select: "name profilePhoto rating" },
        { path: "recipient", select: "name profilePhoto rating" },
      ])

      res.status(201).json({ swapRequest })
    } catch (error) {
      console.error("Swap request creation error:", error)
      res.status(500).json({ error: "Failed to create swap request" })
    }
  },
)

// Get swap requests
router.get("/", authenticateToken, async (req, res) => {
  try {
    const { type = "all", status } = req.query

    const query = {}

    if (type === "sent") {
      query.requester = req.user._id
    } else if (type === "received") {
      query.recipient = req.user._id
    } else {
      query.$or = [{ requester: req.user._id }, { recipient: req.user._id }]
    }

    if (status) {
      query.status = status
    }

    const swapRequests = await SwapRequest.find(query)
      .populate([
        { path: "requester", select: "name profilePhoto rating" },
        { path: "recipient", select: "name profilePhoto rating" },
      ])
      .sort({ createdAt: -1 })

    res.json({ swapRequests })
  } catch (error) {
    console.error("Swap requests fetch error:", error)
    res.status(500).json({ error: "Failed to fetch swap requests" })
  }
})

// Update swap request
router.put(
  "/:id",
  authenticateToken,
  [body("action").isIn(["accept", "reject", "complete", "cancel"]).withMessage("Invalid action")],
  async (req, res) => {
    try {
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({ error: errors.array()[0].msg })
      }

      const { action } = req.body
      const swapRequest = await SwapRequest.findById(req.params.id)

      if (!swapRequest) {
        return res.status(404).json({ error: "Swap request not found" })
      }

      // Check permissions
      const isRecipient = swapRequest.recipient.toString() === req.user._id.toString()
      const isRequester = swapRequest.requester.toString() === req.user._id.toString()

      if (!isRecipient && !isRequester) {
        return res.status(403).json({ error: "Unauthorized" })
      }

      const updateData = {}

      switch (action) {
        case "accept":
          if (!isRecipient) {
            return res.status(403).json({ error: "Only recipient can accept requests" })
          }
          updateData.status = "accepted"
          break

        case "reject":
          if (!isRecipient) {
            return res.status(403).json({ error: "Only recipient can reject requests" })
          }
          updateData.status = "rejected"
          break

        case "complete":
          if (swapRequest.status !== "accepted") {
            return res.status(400).json({ error: "Can only complete accepted requests" })
          }
          updateData.status = "completed"
          updateData.completedAt = new Date()
          break

        case "cancel":
          if (!isRequester) {
            return res.status(403).json({ error: "Only requester can cancel requests" })
          }
          if (swapRequest.status !== "pending") {
            return res.status(400).json({ error: "Can only cancel pending requests" })
          }
          updateData.status = "cancelled"
          break
      }

      const updatedRequest = await SwapRequest.findByIdAndUpdate(req.params.id, updateData, { new: true }).populate([
        { path: "requester", select: "name profilePhoto rating" },
        { path: "recipient", select: "name profilePhoto rating" },
      ])

      res.json({ swapRequest: updatedRequest })
    } catch (error) {
      console.error("Swap request update error:", error)
      res.status(500).json({ error: "Failed to update swap request" })
    }
  },
)

// Delete swap request
router.delete("/:id", authenticateToken, async (req, res) => {
  try {
    const swapRequest = await SwapRequest.findById(req.params.id)

    if (!swapRequest) {
      return res.status(404).json({ error: "Swap request not found" })
    }

    // Only requester can delete their own requests
    if (swapRequest.requester.toString() !== req.user._id.toString()) {
      return res.status(403).json({ error: "Unauthorized" })
    }

    await SwapRequest.findByIdAndDelete(req.params.id)

    res.json({ message: "Swap request deleted successfully" })
  } catch (error) {
    console.error("Swap request deletion error:", error)
    res.status(500).json({ error: "Failed to delete swap request" })
  }
})

export default router
