import { NextResponse } from "next/server"
import connectDB from "@/lib/db"
import User from "@/lib/models/User"
import { requireAuth } from "@/middleware/auth"

export async function GET(request) {
  try {
    const user = await requireAuth(request)
    return NextResponse.json({ user })
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 401 })
  }
}

export async function PUT(request) {
  try {
    await connectDB()
    const user = await requireAuth(request)

    const updates = await request.json()

    // Remove sensitive fields that shouldn't be updated via this endpoint
    delete updates.password
    delete updates.email
    delete updates.isAdmin
    delete updates.isBanned
    delete updates.rating

    const updatedUser = await User.findByIdAndUpdate(user._id, updates, { new: true, runValidators: true }).select(
      "-password",
    )

    return NextResponse.json({ user: updatedUser })
  } catch (error) {
    console.error("Profile update error:", error)
    return NextResponse.json({ error: "Failed to update profile" }, { status: 500 })
  }
}
