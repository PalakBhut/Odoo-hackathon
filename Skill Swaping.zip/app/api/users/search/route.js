import { NextResponse } from "next/server"
import connectDB from "@/lib/db"
import User from "@/lib/models/User"
import { requireAuth } from "@/middleware/auth"

export async function GET(request) {
  try {
    await connectDB()
    await requireAuth(request)

    const { searchParams } = new URL(request.url)
    const skill = searchParams.get("skill")
    const location = searchParams.get("location")
    const page = Number.parseInt(searchParams.get("page")) || 1
    const limit = Number.parseInt(searchParams.get("limit")) || 12
    const skip = (page - 1) * limit

    // Build search query
    const query = {
      isPublic: true,
      isBanned: false,
    }

    if (skill) {
      query.$or = [
        { "skillsOffered.name": { $regex: skill, $options: "i" } },
        { "skillsOffered.description": { $regex: skill, $options: "i" } },
      ]
    }

    if (location) {
      query.location = { $regex: location, $options: "i" }
    }

    const users = await User.find(query)
      .select("-password -email")
      .sort({ "rating.average": -1, createdAt: -1 })
      .skip(skip)
      .limit(limit)

    const total = await User.countDocuments(query)

    return NextResponse.json({
      users,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error("Search error:", error)
    return NextResponse.json({ error: "Failed to search users" }, { status: 500 })
  }
}
