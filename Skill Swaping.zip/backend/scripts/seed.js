import mongoose from "mongoose"
import bcrypt from "bcryptjs"
import dotenv from "dotenv"
dotenv.config() // Load environment variables from .env

import User from "../models/User.js" // Ensure .js extension for ES modules
import SwapRequest from "../models/SwapRequest.js" // Ensure .js extension for ES modules

const sampleUsers = [
  {
    name: "John Doe",
    email: "john@example.com",
    password: "password123",
    location: "New York, NY",
    skillsOffered: [
      { name: "JavaScript", description: "Full-stack web development", level: "Advanced" },
      { name: "React", description: "Modern frontend development", level: "Expert" },
    ],
    skillsWanted: [
      { name: "Python", description: "Data science and machine learning" },
      { name: "Design", description: "UI/UX design principles" },
    ],
    availability: "Evenings",
    isPublic: true,
  },
  {
    name: "Jane Smith",
    email: "jane@example.com",
    password: "password123",
    location: "San Francisco, CA",
    skillsOffered: [
      { name: "Python", description: "Data analysis and ML", level: "Expert" },
      { name: "SQL", description: "Database design and optimization", level: "Advanced" },
    ],
    skillsWanted: [
      { name: "JavaScript", description: "Frontend web development" },
      { name: "Mobile Development", description: "iOS/Android app development" },
    ],
    availability: "Weekends",
    isPublic: true,
  },
  {
    name: "Mike Johnson",
    email: "mike@example.com",
    password: "password123",
    location: "Austin, TX",
    skillsOffered: [
      { name: "Photoshop", description: "Photo editing and design", level: "Advanced" },
      { name: "Photography", description: "Portrait and landscape photography", level: "Expert" },
    ],
    skillsWanted: [
      { name: "Video Editing", description: "Adobe Premiere and After Effects" },
      { name: "Marketing", description: "Digital marketing strategies" },
    ],
    availability: "Flexible",
    isPublic: true,
  },
  // Admin user
  {
    name: "Admin User",
    email: "admin@skillswap.com",
    password: "admin123",
    location: "Remote",
    skillsOffered: [],
    skillsWanted: [],
    availability: "Flexible",
    isPublic: false,
    isAdmin: true,
  },
]

async function seedDatabase() {
  try {
    await mongoose.connect(process.env.MONGODB_URI)
    console.log("✅ Connected to MongoDB")

    // Clear existing data
    await User.deleteMany({})
    await SwapRequest.deleteMany({})
    console.log("🗑️  Cleared existing data")

    // Create sample users
    const createdUsers = []
    for (const userData of sampleUsers) {
      const hashedPassword = await bcrypt.hash(userData.password, 12)
      const user = await User.create({
        ...userData,
        password: hashedPassword,
      })
      createdUsers.push(user)
    }

    console.log("👥 Sample users created successfully")

    // Create some sample swap requests
    if (createdUsers.length >= 3) {
      await SwapRequest.create({
        requester: createdUsers[0]._id,
        recipient: createdUsers[1]._id,
        offeredSkill: { name: "JavaScript", description: "React development help" },
        requestedSkill: { name: "Python", description: "Data analysis basics" },
        message: "Hi! I'd love to help you with React in exchange for Python lessons.",
        status: "pending",
      })

      await SwapRequest.create({
        requester: createdUsers[1]._id,
        recipient: createdUsers[2]._id,
        offeredSkill: { name: "Python", description: "Machine learning basics" },
        requestedSkill: { name: "Photoshop", description: "Photo editing techniques" },
        message: "Would love to trade ML knowledge for design skills!",
        status: "accepted",
      })

      console.log("🔄 Sample swap requests created")
    }

    console.log("\n🎉 Database seeded successfully!")
    console.log("\n📋 Login credentials:")
    console.log("👤 User: john@example.com / password123")
    console.log("👤 User: jane@example.com / password123")
    console.log("👤 User: mike@example.com / password123")
    console.log("🛡️  Admin: admin@skillswap.com / admin123")
  } catch (error) {
    console.error("❌ Seeding error:", error)
  } finally {
    await mongoose.disconnect()
    console.log("📡 Disconnected from MongoDB")
  }
}

seedDatabase()
