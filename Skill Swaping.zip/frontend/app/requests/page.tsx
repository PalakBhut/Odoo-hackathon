"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/contexts/AuthContext"
import { motion } from "framer-motion"
import { MessageSquare, CheckCircle, XCircle, Ban, Send, Inbox } from "lucide-react"
import Navbar from "@/components/Navbar"
import toast from "react-hot-toast"
import api from "@/lib/api"
import { formatRelativeTime, getStatusColor } from "@/lib/utils"

interface SwapRequest {
  _id: string
  requester: {
    _id: string
    name: string
    profilePhoto?: string
  }
  recipient: {
    _id: string
    name: string
    profilePhoto?: string
  }
  offeredSkill: {
    name: string
    description?: string
  }
  requestedSkill: {
    name: string
    description?: string
  }
  message?: string
  status: "pending" | "accepted" | "rejected" | "completed" | "cancelled"
  createdAt: string
}

export default function RequestsPage() {
  const [requests, setRequests] = useState<SwapRequest[]>([])
  const [loading, setLoading] = useState(true)
  const [filterType, setFilterType] = useState<"all" | "sent" | "received">("all")
  const [filterStatus, setFilterStatus] = useState<string>("all")
  const { user, isAuthenticated } = useAuth()

  useEffect(() => {
    if (!isAuthenticated) {
      window.location.href = "/login"
      return
    }
    fetchRequests()
  }, [isAuthenticated, filterType, filterStatus])

  const fetchRequests = async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      if (filterType !== "all") params.append("type", filterType)
      if (filterStatus !== "all") params.append("status", filterStatus)

      const response = await api.get(`/swap-requests?${params.toString()}`)
      setRequests(response.data.swapRequests)
    } catch (error) {
      toast.error(error.response?.data?.error || "Failed to fetch swap requests")
    } finally {
      setLoading(false)
    }
  }

  const handleAction = async (requestId: string, action: string) => {
    try {
      await api.put(`/swap-requests/${requestId}`, { action })
      toast.success(`Request ${action}ed successfully!`)
      fetchRequests() // Re-fetch requests to update UI
    } catch (error) {
      toast.error(error.response?.data?.error || `Failed to ${action} request`)
    }
  }

  if (!isAuthenticated) {
    return null
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Navbar />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">Your Swap Requests</h1>
          <p className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            Manage your incoming and outgoing skill exchange requests.
          </p>
        </motion.div>

        {/* Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 mb-8 flex flex-col sm:flex-row gap-4 justify-center items-center"
        >
          <div className="flex gap-2">
            <button
              onClick={() => setFilterType("all")}
              className={`px-4 py-2 rounded-lg text-sm font-medium ${
                filterType === "all"
                  ? "bg-blue-600 text-white"
                  : "bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-300 dark:hover:bg-gray-600"
              }`}
            >
              All Requests
            </button>
            <button
              onClick={() => setFilterType("received")}
              className={`px-4 py-2 rounded-lg text-sm font-medium ${
                filterType === "received"
                  ? "bg-blue-600 text-white"
                  : "bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-300 dark:hover:bg-gray-600"
              }`}
            >
              <Inbox className="inline-block w-4 h-4 mr-1" /> Received
            </button>
            <button
              onClick={() => setFilterType("sent")}
              className={`px-4 py-2 rounded-lg text-sm font-medium ${
                filterType === "sent"
                  ? "bg-blue-600 text-white"
                  : "bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600"
              }`}
            >
              <Send className="inline-block w-4 h-4 mr-1" /> Sent
            </button>
          </div>

          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white text-sm"
          >
            <option value="all">All Statuses</option>
            <option value="pending">Pending</option>
            <option value="accepted">Accepted</option>
            <option value="completed">Completed</option>
            <option value="rejected">Rejected</option>
            <option value="cancelled">Cancelled</option>
          </select>
        </motion.div>

        {/* Request List */}
        {loading ? (
          <div className="grid gap-6">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 animate-pulse">
                <div className="flex items-center mb-4">
                  <div className="w-10 h-10 rounded-full bg-gray-300 dark:bg-gray-600 mr-3"></div>
                  <div className="h-4 bg-gray-300 dark:bg-gray-600 w-1/3 rounded"></div>
                </div>
                <div className="h-4 bg-gray-300 dark:bg-gray-600 w-2/3 rounded mb-2"></div>
                <div className="h-4 bg-gray-300 dark:bg-gray-600 w-1/2 rounded mb-4"></div>
                <div className="h-8 bg-gray-300 dark:bg-gray-600 w-full rounded-lg"></div>
              </div>
            ))}
          </div>
        ) : requests.length > 0 ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="grid gap-6"
          >
            {requests.map((request) => {
              const isSent = request.requester._id === user?.id
              const otherUser = isSent ? request.recipient : request.requester

              return (
                <div
                  key={request._id}
                  className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 border border-gray-200 dark:border-gray-700"
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center">
                      {otherUser.profilePhoto ? (
                        <img
                          src={otherUser.profilePhoto || "/placeholder.svg"}
                          alt={otherUser.name}
                          className="w-10 h-10 rounded-full object-cover mr-3"
                        />
                      ) : (
                        <div className="w-10 h-10 bg-gray-300 dark:bg-gray-600 rounded-full flex items-center justify-center mr-3">
                          <MessageSquare className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                        </div>
                      )}
                      <div>
                        <p className="text-lg font-semibold text-gray-900 dark:text-white">
                          {isSent ? "Request to" : "Request from"} {otherUser.name}
                        </p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          {formatRelativeTime(request.createdAt)}
                        </p>
                      </div>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(request.status)}`}>
                      {request.status.charAt(0).toUpperCase() + request.status.slice(1)}
                    </span>
                  </div>

                  <div className="mb-4 text-gray-700 dark:text-gray-300">
                    <p>
                      <span className="font-medium">Offering:</span> {request.offeredSkill.name}
                      {request.offeredSkill.description && ` (${request.offeredSkill.description})`}
                    </p>
                    <p>
                      <span className="font-medium">Requesting:</span> {request.requestedSkill.name}
                      {request.requestedSkill.description && ` (${request.requestedSkill.description})`}
                    </p>
                    {request.message && <p className="mt-2 text-sm italic">"{request.message}"</p>}
                  </div>

                  {/* Actions */}
                  <div className="flex flex-wrap gap-3">
                    {request.status === "pending" && isSent && (
                      <button
                        onClick={() => handleAction(request._id, "cancel")}
                        className="flex-1 sm:flex-none bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition-colors font-medium flex items-center justify-center space-x-2"
                      >
                        <Ban className="w-4 h-4" />
                        <span>Cancel Request</span>
                      </button>
                    )}
                    {request.status === "pending" && !isSent && (
                      <>
                        <button
                          onClick={() => handleAction(request._id, "accept")}
                          className="flex-1 sm:flex-none bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors font-medium flex items-center justify-center space-x-2"
                        >
                          <CheckCircle className="w-4 h-4" />
                          <span>Accept</span>
                        </button>
                        <button
                          onClick={() => handleAction(request._id, "reject")}
                          className="flex-1 sm:flex-none bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition-colors font-medium flex items-center justify-center space-x-2"
                        >
                          <XCircle className="w-4 h-4" />
                          <span>Reject</span>
                        </button>
                      </>
                    )}
                    {request.status === "accepted" && (isSent || !isSent) && (
                      <button
                        onClick={() => handleAction(request._id, "complete")}
                        className="flex-1 sm:flex-none bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors font-medium flex items-center justify-center space-x-2"
                      >
                        <CheckCircle className="w-4 h-4" />
                        <span>Mark as Completed</span>
                      </button>
                    )}
                  </div>
                </div>
              )
            })}
          </motion.div>
        ) : (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-12">
            <MessageSquare className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">No swap requests found</h3>
            <p className="text-gray-600 dark:text-gray-400">
              You haven't sent or received any requests yet. Start browsing to connect with others!
            </p>
          </motion.div>
        )}
      </div>
    </div>
  )
}
