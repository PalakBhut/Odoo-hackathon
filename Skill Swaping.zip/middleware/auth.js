import { verifyToken, getTokenFromRequest } from "@/lib/auth"
import User from "@/lib/models/User"
import connectDB from "@/lib/db"

export async function authenticateUser(request) {
  await connectDB()

  const token = getTokenFromRequest(request)
  if (!token) {
    return null
  }

  const decoded = verifyToken(token)
  if (!decoded) {
    return null
  }

  const user = await User.findById(decoded.userId).select("-password")
  if (!user || user.isBanned) {
    return null
  }

  return user
}

export async function requireAuth(request) {
  const user = await authenticateUser(request)
  if (!user) {
    throw new Error("Authentication required")
  }
  return user
}

export async function requireAdmin(request) {
  const user = await requireAuth(request)
  if (!user.isAdmin) {
    throw new Error("Admin access required")
  }
  return user
}
