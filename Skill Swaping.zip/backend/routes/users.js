import express from "express"
import { body, validationResult } from "express-validator"
import User from "../models/User.js" // Ensure .js extension
import { authenticateToken } from "../middleware/auth.js" // Ensure .js extension

const router = express.Router()

// Get user profile
router.get("/profile", authenticateToken, async (req, res) => {
  try {
    res.json({ user: req.user })
  } catch (error) {
    console.error("Get profile error:", error)
    res.status(500).json({ error: "Failed to get profile" })
  }
})

// Update user profile
router.put(
  "/profile",
  authenticateToken,
  [
    body("name").optional().trim().isLength({ min: 2 }).withMessage("Name must be at least 2 characters"),
    body("location").optional().trim(),
    body("availability").optional().isIn(["Weekends", "Evenings", "Flexible", "Custom"]),
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        // Log validation errors from express-validator
        console.log("Validation errors from express-validator:", errors.array())
        return res.status(400).json({ error: errors.array()[0].msg })
      }

      const updates = { ...req.body } // Create a copy to avoid modifying req.body directly

      // Remove sensitive fields that shouldn't be updated via this endpoint
      delete updates.password
      delete updates.email
      delete updates.isAdmin
      delete updates.isBanned
      delete updates.rating

      // Log the updates received by the backend
      console.log("Backend received updates for profile:", updates)

      const updatedUser = await User.findByIdAndUpdate(req.user._id, updates, {
        new: true,
        runValidators: true, // Crucial for schema validation on update
      }).select("-password")

      if (!updatedUser) {
        console.error("User not found during update for ID:", req.user._id)
        return res.status(404).json({ error: "User not found" })
      }

      // Log the user data after successful database update
      console.log("User profile successfully updated in DB:", updatedUser)

      res.json({ user: updatedUser })
    } catch (error) {
      console.error("Profile update error (backend):", error)
      // More specific error handling for Mongoose validation errors
      if (error.name === "ValidationError") {
        const messages = Object.values(error.errors).map((err) => err.message)
        return res.status(400).json({ error: `Validation failed: ${messages.join(", ")}` })
      }
      res.status(500).json({ error: "Failed to update profile" })
    }
  },
)

// Search users
router.get("/search", authenticateToken, async (req, res) => {
  try {
    const { skill, location, page = 1, limit = 12 } = req.query
    const skip = (page - 1) * limit

    // Build search query
    const query = {
      isPublic: true,
      isBanned: false,
      _id: { $ne: req.user._id }, // Exclude current user
    }

    if (skill) {
      // Enhanced search: look for skill in both skillsOffered and skillsWanted
      query.$or = [
        { "skillsOffered.name": { $regex: skill, $options: "i" } },
        { "skillsOffered.description": { $regex: skill, $options: "i" } },
        { "skillsWanted.name": { $regex: skill, $options: "i" } }, // Added this line
        { "skillsWanted.description": { $regex: skill, $options: "i" } }, // Added this line
      ]
    }

    if (location) {
      query.location = { $regex: location, $options: "i" }
    }

    const users = await User.find(query)
      .select("-password -email")
      .sort({ "rating.average": -1, createdAt: -1 })
      .skip(skip)
      .limit(Number.parseInt(limit))

    const total = await User.countDocuments(query)

    res.json({
      users,
      pagination: {
        page: Number.parseInt(page),
        limit: Number.parseInt(limit),
        total,
        pages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error("Search error:", error)
    res.status(500).json({ error: "Failed to search users" })
  }
})

// Get user by ID
router.get("/:id", authenticateToken, async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select("-password -email")

    if (!user) {
      return res.status(404).json({ error: "User not found" })
    }

    if (!user.isPublic && user._id.toString() !== req.user._id.toString()) {
      return res.status(403).json({ error: "Profile is private" })
    }

    res.json({ user })
  } catch (error) {
    console.error("Get user error:", error)
    res.status(500).json({ error: "Failed to get user" })
  }
})

export default router
