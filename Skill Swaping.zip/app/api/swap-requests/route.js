import { NextResponse } from "next/server"
import connectDB from "@/lib/db"
import SwapRequest from "@/lib/models/SwapRequest"
import User from "@/lib/models/User"
import { requireAuth } from "@/middleware/auth"

export async function POST(request) {
  try {
    await connectDB()
    const user = await requireAuth(request)

    const { recipientId, offeredSkill, requestedSkill, message } = await request.json()

    // Validation
    if (!recipientId || !offeredSkill || !requestedSkill) {
      return NextResponse.json({ error: "Recipient, offered skill, and requested skill are required" }, { status: 400 })
    }

    // Check if recipient exists and is not banned
    const recipient = await User.findById(recipientId)
    if (!recipient || recipient.isBanned) {
      return NextResponse.json({ error: "Recipient not found or unavailable" }, { status: 404 })
    }

    // Prevent self-requests
    if (user._id.toString() === recipientId) {
      return NextResponse.json({ error: "Cannot send swap request to yourself" }, { status: 400 })
    }

    // Check for existing pending request
    const existingRequest = await SwapRequest.findOne({
      requester: user._id,
      recipient: recipientId,
      status: "pending",
    })

    if (existingRequest) {
      return NextResponse.json({ error: "You already have a pending request with this user" }, { status: 400 })
    }

    // Create swap request
    const swapRequest = await SwapRequest.create({
      requester: user._id,
      recipient: recipientId,
      offeredSkill,
      requestedSkill,
      message,
    })

    // Populate the request with user data
    await swapRequest.populate([
      { path: "requester", select: "name profilePhoto rating" },
      { path: "recipient", select: "name profilePhoto rating" },
    ])

    return NextResponse.json({ swapRequest }, { status: 201 })
  } catch (error) {
    console.error("Swap request creation error:", error)
    return NextResponse.json({ error: "Failed to create swap request" }, { status: 500 })
  }
}

export async function GET(request) {
  try {
    await connectDB()
    const user = await requireAuth(request)

    const { searchParams } = new URL(request.url)
    const type = searchParams.get("type") || "all" // 'sent', 'received', 'all'
    const status = searchParams.get("status")

    const query = {}

    if (type === "sent") {
      query.requester = user._id
    } else if (type === "received") {
      query.recipient = user._id
    } else {
      query.$or = [{ requester: user._id }, { recipient: user._id }]
    }

    if (status) {
      query.status = status
    }

    const swapRequests = await SwapRequest.find(query)
      .populate([
        { path: "requester", select: "name profilePhoto rating" },
        { path: "recipient", select: "name profilePhoto rating" },
      ])
      .sort({ createdAt: -1 })

    return NextResponse.json({ swapRequests })
  } catch (error) {
    console.error("Swap requests fetch error:", error)
    return NextResponse.json({ error: "Failed to fetch swap requests" }, { status: 500 })
  }
}
