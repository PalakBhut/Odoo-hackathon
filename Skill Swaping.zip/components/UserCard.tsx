"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { MapPin, Star, MessageSquare, User } from "lucide-react"
import { getSkillLevelColor } from "@/lib/utils"
import SwapRequestModal from "./SwapRequestModal"

interface UserCardProps {
  user: {
    _id: string
    name: string
    location?: string
    profilePhoto?: string
    skillsOffered: Array<{
      name: string
      description: string
      level: string
    }>
    skillsWanted: Array<{
      name: string
      description: string
    }>
    availability: string
    rating: {
      average: number
      count: number
    }
  }
}

export default function UserCard({ user }: UserCardProps) {
  const [showModal, setShowModal] = useState(false)

  return (
    <>
      <motion.div
        whileHover={{ y: -4 }}
        className="bg-white dark:bg-gray-800 rounded-lg shadow-md hover:shadow-lg transition-all duration-300 p-6 border border-gray-200 dark:border-gray-700"
      >
        {/* Profile Header */}
        <div className="text-center mb-4">
          {user.profilePhoto ? (
            <img
              src={user.profilePhoto || "/placeholder.svg"}
              alt={user.name}
              className="w-16 h-16 rounded-full mx-auto mb-3 object-cover"
            />
          ) : (
            <div className="w-16 h-16 bg-gray-300 dark:bg-gray-600 rounded-full mx-auto mb-3 flex items-center justify-center">
              <User className="w-8 h-8 text-gray-600 dark:text-gray-400" />
            </div>
          )}
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{user.name}</h3>
          {user.location && (
            <div className="flex items-center justify-center text-sm text-gray-600 dark:text-gray-400 mt-1">
              <MapPin className="w-4 h-4 mr-1" />
              {user.location}
            </div>
          )}
        </div>

        {/* Rating */}
        {user.rating.count > 0 && (
          <div className="flex items-center justify-center mb-4">
            <Star className="w-4 h-4 text-yellow-400 fill-current" />
            <span className="ml-1 text-sm font-medium text-gray-900 dark:text-white">
              {user.rating.average.toFixed(1)}
            </span>
            <span className="ml-1 text-sm text-gray-600 dark:text-gray-400">({user.rating.count} reviews)</span>
          </div>
        )}

        {/* Skills Offered */}
        <div className="mb-4">
          <h4 className="text-sm font-medium text-gray-900 dark:text-white mb-2">Offers:</h4>
          <div className="space-y-1">
            {user.skillsOffered.slice(0, 2).map((skill, index) => (
              <div key={index} className="flex items-center justify-between">
                <span className="text-sm text-gray-700 dark:text-gray-300 truncate flex-1">{skill.name}</span>
                <span className={`text-xs px-2 py-1 rounded-full ${getSkillLevelColor(skill.level)}`}>
                  {skill.level}
                </span>
              </div>
            ))}
            {user.skillsOffered.length > 2 && (
              <div className="text-xs text-gray-500 dark:text-gray-400">+{user.skillsOffered.length - 2} more</div>
            )}
          </div>
        </div>

        {/* Skills Wanted */}
        <div className="mb-4">
          <h4 className="text-sm font-medium text-gray-900 dark:text-white mb-2">Wants to learn:</h4>
          <div className="space-y-1">
            {user.skillsWanted.slice(0, 2).map((skill, index) => (
              <div key={index} className="text-sm text-gray-700 dark:text-gray-300 truncate">
                {skill.name}
              </div>
            ))}
            {user.skillsWanted.length > 2 && (
              <div className="text-xs text-gray-500 dark:text-gray-400">+{user.skillsWanted.length - 2} more</div>
            )}
          </div>
        </div>

        {/* Availability */}
        <div className="mb-4">
          <span className="availability-badge">{user.availability}</span>
        </div>

        {/* Action Button */}
        <button
          onClick={() => setShowModal(true)}
          className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors font-medium flex items-center justify-center space-x-2"
        >
          <MessageSquare className="w-4 h-4" />
          <span>Send Request</span>
        </button>
      </motion.div>

      {showModal && <SwapRequestModal recipient={user} onClose={() => setShowModal(false)} />}
    </>
  )
}
