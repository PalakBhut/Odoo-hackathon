"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { useAuth } from "@/contexts/AuthContext"
import { motion } from "framer-motion"
import { User, MapPin, Briefcase, Target, Clock, Camera, Save, Plus, X } from "lucide-react"
import Navbar from "@/components/Navbar"
import toast from "react-hot-toast"
import api from "@/lib/api"

interface Skill {
  name: string
  description?: string
  level?: string
}

export default function ProfilePage() {
  const { user, isAuthenticated, updateUser } = useAuth()
  const router = useRouter()
  const searchParams = useSearchParams()
  const isSetupMode = searchParams.get("setup") === "true"

  const [formData, setFormData] = useState({
    name: user?.name || "",
    email: user?.email || "", // Email is read-only
    location: user?.location || "",
    profilePhoto: user?.profilePhoto || "",
    skillsOffered: user?.skillsOffered || [],
    skillsWanted: user?.skillsWanted || [],
    availability: user?.availability || "Flexible",
    customAvailability: user?.customAvailability || "",
    isPublic: user?.isPublic ?? true,
  })
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [newSkillOffered, setNewSkillOffered] = useState<Skill>({ name: "", description: "", level: "Beginner" })
  const [newSkillWanted, setNewSkillWanted] = useState<Skill>({ name: "", description: "" })

  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/login")
      return
    }
    if (user) {
      setFormData({
        name: user.name || "",
        email: user.email || "",
        location: user.location || "",
        profilePhoto: user.profilePhoto || "",
        skillsOffered: user.skillsOffered || [],
        skillsWanted: user.skillsWanted || [],
        availability: user.availability || "Flexible",
        customAvailability: user.customAvailability || "",
        isPublic: user.isPublic ?? true,
      })
      setLoading(false)
    } else {
      // If user is null but isAuthenticated is true, it means user data is still loading
      // or there was an issue fetching it. We can try to re-fetch or redirect.
      // For now, rely on AuthProvider's loading state.
      if (!isAuthenticated) {
        setLoading(false) // If not authenticated, stop loading and redirect
      }
    }
  }, [user, isAuthenticated, router])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type, checked } = e.target as HTMLInputElement
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }))
  }

  const handleAddSkill = (type: "offered" | "wanted") => {
    if (type === "offered" && newSkillOffered.name.trim()) {
      setFormData((prev) => ({
        ...prev,
        skillsOffered: [...prev.skillsOffered, newSkillOffered],
      }))
      setNewSkillOffered({ name: "", description: "", level: "Beginner" })
    } else if (type === "wanted" && newSkillWanted.name.trim()) {
      setFormData((prev) => ({
        ...prev,
        skillsWanted: [...prev.skillsWanted, newSkillWanted],
      }))
      setNewSkillWanted({ name: "", description: "" })
    }
  }

  const handleRemoveSkill = (type: "offered" | "wanted", index: number) => {
    if (type === "offered") {
      setFormData((prev) => ({
        ...prev,
        skillsOffered: prev.skillsOffered.filter((_, i) => i !== index),
      }))
    } else {
      setFormData((prev) => ({
        ...prev,
        skillsWanted: prev.skillsWanted.filter((_, i) => i !== index),
      }))
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitting(true)

    // Add this line to log the data being sent
    console.log("Submitting profile formData:", formData)

    try {
      const response = await api.put("/users/profile", formData)
      updateUser(response.data.user)
      toast.success("Profile updated successfully!")
      if (isSetupMode) {
        router.push("/browse") // Redirect after initial setup
      }
    } catch (error) {
      // Add this line to log frontend errors
      console.error("Frontend profile update error:", error)
      toast.error(error.response?.data?.error || "Failed to update profile")
    } finally {
      setSubmitting(false)
    }
  }

  if (loading) {
    return null // Loading component handles the display
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Navbar />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {isSetupMode && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 p-4 rounded-lg mb-6 text-center"
          >
            <p className="font-medium">
              Welcome to SkillSwap! Please complete your profile to start exchanging skills.
            </p>
          </motion.div>
        )}

        {/* Header */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">Your Profile</h1>
          <p className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            Manage your personal information, skills, and availability.
          </p>
        </motion.div>

        {/* Profile Form */}
        <motion.form
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          onSubmit={handleSubmit}
          className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 mb-8 space-y-6"
        >
          {/* Basic Info */}
          <div>
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
              <User className="w-5 h-5 mr-2" /> Basic Information
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  required
                />
              </div>
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-100 dark:bg-gray-700 text-gray-500 dark:text-gray-400 cursor-not-allowed"
                  disabled
                />
              </div>
              <div>
                <label htmlFor="location" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Location
                </label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="text"
                    id="location"
                    name="location"
                    value={formData.location}
                    onChange={handleInputChange}
                    className="w-full pl-10 pr-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    placeholder="e.g., New York, NY"
                  />
                </div>
              </div>
              <div>
                <label
                  htmlFor="profilePhoto"
                  className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1"
                >
                  Profile Photo URL
                </label>
                <div className="relative">
                  <Camera className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="text"
                    id="profilePhoto"
                    name="profilePhoto"
                    value={formData.profilePhoto}
                    onChange={handleInputChange}
                    className="w-full pl-10 pr-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    placeholder="URL to your profile image"
                  />
                </div>
                {formData.profilePhoto && (
                  <img
                    src={formData.profilePhoto || "/placeholder.svg"}
                    alt="Profile Preview"
                    className="w-20 h-20 rounded-full object-cover mt-3 mx-auto"
                  />
                )}
              </div>
            </div>
          </div>

          {/* Skills Offered */}
          <div>
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
              <Briefcase className="w-5 h-5 mr-2" /> Skills You Offer
            </h2>
            <div className="space-y-3">
              {formData.skillsOffered.map((skill, index) => (
                <div
                  key={index}
                  className="flex items-center bg-gray-100 dark:bg-gray-700 p-3 rounded-lg justify-between"
                >
                  <div>
                    <p className="font-medium text-gray-900 dark:text-white">{skill.name}</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{skill.description}</p>
                    <span className="text-xs text-gray-500 dark:text-gray-400">{skill.level}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleRemoveSkill("offered", index)}
                    className="text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300 p-1 rounded-full hover:bg-gray-200 dark:hover:bg-gray-600"
                  >
                    <X className="w-5 h-5" />
                    <span className="sr-only">Remove skill</span>
                  </button>
                </div>
              ))}
              <div className="flex flex-col gap-2">
                <input
                  type="text"
                  placeholder="Skill name (e.g., Web Development)"
                  value={newSkillOffered.name}
                  onChange={(e) => setNewSkillOffered({ ...newSkillOffered, name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                />
                <textarea
                  placeholder="Description (e.g., React, Node.js, MongoDB)"
                  value={newSkillOffered.description}
                  onChange={(e) => setNewSkillOffered({ ...newSkillOffered, description: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  rows={2}
                />
                <select
                  value={newSkillOffered.level}
                  onChange={(e) => setNewSkillOffered({ ...newSkillOffered, level: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                >
                  <option value="Beginner">Beginner</option>
                  <option value="Intermediate">Intermediate</option>
                  <option value="Advanced">Advanced</option>
                  <option value="Expert">Expert</option>
                </select>
                <button
                  type="button"
                  onClick={() => handleAddSkill("offered")}
                  className="flex items-center justify-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed"
                  disabled={!newSkillOffered.name.trim()}
                >
                  <Plus className="w-4 h-4 mr-2" /> Add Offered Skill
                </button>
              </div>
            </div>
          </div>

          {/* Skills Wanted */}
          <div>
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
              <Target className="w-5 h-5 mr-2" /> Skills You Want to Learn
            </h2>
            <div className="space-y-3">
              {formData.skillsWanted.map((skill, index) => (
                <div
                  key={index}
                  className="flex items-center bg-gray-100 dark:bg-gray-700 p-3 rounded-lg justify-between"
                >
                  <div>
                    <p className="font-medium text-gray-900 dark:text-white">{skill.name}</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{skill.description}</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleRemoveSkill("wanted", index)}
                    className="text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300 p-1 rounded-full hover:bg-gray-200 dark:hover:bg-gray-600"
                  >
                    <X className="w-5 h-5" />
                    <span className="sr-only">Remove skill</span>
                  </button>
                </div>
              ))}
              <div className="flex flex-col gap-2">
                <input
                  type="text"
                  placeholder="Skill name (e.g., UI/UX Design)"
                  value={newSkillWanted.name}
                  onChange={(e) => setNewSkillWanted({ ...newSkillWanted, name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                />
                <textarea
                  placeholder="Description (e.g., Figma, Adobe XD)"
                  value={newSkillWanted.description}
                  onChange={(e) => setNewSkillWanted({ ...newSkillWanted, description: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  rows={2}
                />
                <button
                  type="button"
                  onClick={() => handleAddSkill("wanted")}
                  className="flex items-center justify-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed"
                  disabled={!newSkillWanted.name.trim()}
                >
                  <Plus className="w-4 h-4 mr-2" /> Add Wanted Skill
                </button>
              </div>
            </div>
          </div>

          {/* Availability */}
          <div>
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
              <Clock className="w-5 h-5 mr-2" /> Availability
            </h2>
            <select
              name="availability"
              value={formData.availability}
              onChange={handleInputChange}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            >
              <option value="Flexible">Flexible</option>
              <option value="Weekends">Weekends</option>
              <option value="Evenings">Evenings</option>
              <option value="Custom">Custom (specify below)</option>
            </select>
            {formData.availability === "Custom" && (
              <textarea
                name="customAvailability"
                placeholder="e.g., 'Mondays and Wednesdays after 6 PM PST'"
                value={formData.customAvailability}
                onChange={handleInputChange}
                className="w-full px-3 py-2 mt-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                rows={2}
              />
            )}
          </div>

          {/* Profile Visibility */}
          <div className="flex items-center">
            <input
              type="checkbox"
              id="isPublic"
              name="isPublic"
              checked={formData.isPublic}
              onChange={handleInputChange}
              className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded dark:border-gray-600 dark:bg-gray-700"
            />
            <label htmlFor="isPublic" className="ml-2 block text-sm text-gray-900 dark:text-white">
              Make my profile public (visible to other users)
            </label>
          </div>

          {/* Save Button */}
          <div>
            <button
              type="submit"
              disabled={submitting}
              className="w-full flex items-center justify-center px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {submitting ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <Save className="w-5 h-5 mr-2" />
                  <span>Save Profile</span>
                </>
              )}
            </button>
          </div>
        </motion.form>
      </div>
    </div>
  )
}
